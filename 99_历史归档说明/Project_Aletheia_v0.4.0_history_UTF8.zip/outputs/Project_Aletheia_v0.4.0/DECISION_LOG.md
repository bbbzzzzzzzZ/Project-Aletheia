---
title: Decision Log
layer: project-governance
status: stable
version: 0.4.0
updated: 2026-09-15
---

# Decision Log

本文件记录会影响整个项目的结构性决定。它回答“项目接受了什么方向决定”；术语正文由 [`GLOSSARY.md`](GLOSSARY.md) 维护，文档引用资格由 [`DOCUMENT_STATUS.md`](DOCUMENT_STATUS.md) 维护，命题、理由、证据与反例由 [`03_Aletheia_Framework/`](03_Aletheia_Framework/) 维护。

自 `D-014` 起，新的 Accepted 决定必须同时记录决定主体、确认主体、确认来源、确认范围、Source ID、替代关系、受影响文档和未决问题。来源身份与项目确认记录见 [`08_Research_Workbench/05_Provenance_and_Decision_Records/`](08_Research_Workbench/05_Provenance_and_Decision_Records/)。项目内部确认只证明 Project Aletheia 的决定链，不是现实公共授权。

## D-001 · 项目从具体制度上移到制度哲学

- 状态：Accepted
- 日期：2026-08-11
- 决定：根目录从劳动、教育、经济和政治制度上移到“需求—责任—权力如何保持一致”的核心问题。
- 理由：具体制度是同一理论框架的应用，不能反向成为全部项目的前提。
- 后果：原社会制度白皮书降为前一阶段框架与应用层资料。

## D-002 · 核心问题与理论答案分离

- 状态：Accepted
- 日期：2026-08-11
- 决定：`00_Core_Question/` 负责精确提出问题；`03_Aletheia_Framework/` 负责当前答案。
- 理由：避免同一结论在不同层重复并产生版本冲突。
- 后果：核心问题文档保持 `question`，通过链接指向当前模型。

## D-003 · 哲学传统不作为项目权威

- 状态：Accepted
- 日期：2026-08-11
- 决定：思想家文档只记录问题关联、可借用概念、冲突和证据，不直接生成第一原则。
- 理由：Aletheia 的主张必须独立说明理由，并接受反例。

## D-004 · 框架、机制与实施参数分层

- 状态：Accepted
- 日期：2026-08-11
- 决定：根框架只写原则和接口；流程写入制度模块；具体数值和算法留到实施层。
- 理由：防止研究总纲膨胀成未经验证的法典。

## D-005 · 需求不直接产生支配权

- 状态：Accepted
- 日期：2026-08-11
- 决定：需求首先产生表达、说明、请求协作和自主追求的资格；公共资源调用和影响他人的权限需要额外条件。
- 理由：同时保护需求表达与他人自主，防止把需求等同于命令。

## D-006 · 旧项目文件分层导入而不升级为当前基线

- 状态：Accepted
- 日期：2026-08-11
- 决定：旧资料索引、定义审计和修订过程进入 `08_Research_Workbench/`；候选机制进入应用层下级目录；参数稿与旧总纲明确标为历史材料。
- 理由：让已经完成的工作可检索、可追溯，同时防止旧文件中的“已确定”“正式”和具体参数覆盖当前 `GLOSSARY.md`、`DOCUMENT_STATUS.md` 与第一原则。
- 后果：引用旧文件时必须同时说明其原日期与当前替代入口；源文件保留原地，本包只保存副本。

## D-007 · 将主体社区纳入城市渐进可达的候选机制

- 状态：Accepted
- 日期：2026-08-11
- 背景：既有城市的建筑结构、资金、施工和时间条件可能使全城深度改造无法一次完成；只等待普遍改造会让当前需求长期得不到回应，只建设封闭机构又可能产生隔离。
- 决定：接受把“主体社区—可达走廊—城市网络”作为跨制度候选机制进入研究，而不是接受其为所有情境的固定建设顺序。具体立项必须先比较直接改造共同空间、分散支持、主体社区及其组合；只有在使用者实质参与和可撤回授权成立、全城最低义务不被削弱、比较结果支持时，才进入节点建设。
- 理由：让有限资源优先形成完整、可使用的生活节点，同时保留成员进入共同城市、家属继续工作生活以及机制向外扩展的可能。
- 后果：主体社区必须自由、知情、自愿进入并真实可退出，允许家庭共同生活但不得依赖强制无偿照护；福利和必要服务不得以迁入为条件；其存在不能免除其他地区既有的基本安全、可达与合理便利责任。居民目标形成权、专业判断权、公共资源责任、服务执行权和独立救济权必须拆分。
- 未采用方案：把全城一次性深度改造作为任何行动的前提；以身份强制分配、限制迁出的封闭社区；以已建专属社区为由停止共同城市更新。
- 替代关系：本决定建立机制研究方向，不规定具体群体、选址、规模、预算、席位比例或工程标准；这些内容仍须试点、证据和授权程序确定。

## D-008 · 采用目的轴与制度生成轴

- 状态：Accepted
- 日期：2026-08-11
- 背景：项目来源同时强调“人—关系—社会—制度”和“需求—责任—权力—制度”，但两者回答的问题不同；简写后的第二条链还可能被误读为需求或责任自动生成权力。
- 决定：将两者作为 Aletheia 世界观中的两条互相约束的轴。目的与层级轴为 `人 → 关系 → 社会 → 制度`；制度生成与运行轴为 `需求 → 表达 / 请求 → 共同任务 → 责任角色 → 能力匹配与授权 → 有限权限 → 执行 → 反馈与退出`。
- 理由：前者确保制度服务具体的人及其关系，后者说明需求必须经过影响审查、责任、能力和授权才能形成共同制度行动。
- 后果：任何下游制度既要说明“为谁存在、怎样改变关系”，也要说明责任与权限的生成、监督和退出。
- 未采用方案：把两条轴合并为 `需求 → 责任 → 权力 → 制度` 的自动因果链；只谈个人而忽略关系塑造；只谈制度程序而忘记具体的人。
- 后续结构说明（`0.2.9`）：保留本决定的目的与层级边界，但撤销把制度生成轴归入“世界观”的文件分类。《世界观》只保存人、关系、社会与制度的位置以及非制度空间；《制度生成语法》作为独立工具，只对另行成立的候选共同协调事项开放。此说明不改写本决定的历史正文，也不撤销 `D-016` 对任务生命周期和制度形成、修正循环的区分。

## D-009 · 采用开放主体与生命周期边界

- 状态：Accepted
- 日期：2026-08-11
- 背景：来源对话反对用一次教育和一种职业固定人的一生，用户进一步确认未成年阶段侧重发现自己，成年阶段保护本人自定义生活。
- 决定：把人描述为在身体、历史、关系和现实限度中仍可能终身发展能力并修订方向的开放主体。未成年人拥有逐步增长的表达和决定空间；成年人默认拥有生活方向决定权；任何年龄都保留重新学习、暂停和转向的机会。
- 理由：同时保护人的发展可能、成年自治和未成年人的主体地位。
- 后果：教育提供可重新进入的支持，而非终身考核；资格、身份和能力记录必须可更新、失效和退出。
- 未采用方案：把人写成出厂定型设备、可无限塑造的空白、可持续加载的人力模块库，或必须不断优化的项目。

## D-010 · 私人能力图谱与公共能力池分离

- 状态：Accepted
- 日期：2026-08-11
- 背景：能力发现首先服务本人认识和实现自己的想法；劳动模块的能力池服务公共责任与其他协作任务。若共用同一数据库，会把自我探索变成公共调用准备。
- 决定：个人侧按 `能力发现 → 私人个人能力图谱 → 本人细粒度授权 → 公共能力池` 形成；任务侧按 `需求审查 → 共同任务确认 → 任务池` 形成。两侧只能通过条件匹配、邀请、本人再次确认、任务承诺与有限权限依次连接。
- 理由：使能力数据用途、联系资格、承担意愿和执行权限彼此独立。
- 后果：个人能力图谱默认私有；进入公共能力池不等于向所有人公开、同意联系、接受任务或承担义务；拒绝邀请不得自动影响人格评价和基本保障。
- 未采用方案：把完整个人档案直接接入任务池；按能力自动调度；把一时能力转化为终身职业身份。
- 后续状态（`0.1.6`）：`D-018` 细化本决定中单一的“邀请—本人确认—任务承诺”路径。普通自愿任务继续按该路径进入；有约束力的公共责任任务只能使用经正当用途取得的最小能力信息形成候选，随后须走独立个案义务程序并另行授权。能力数据用途限定、不得自动调度及能力不等于义务的边界继续有效。

## D-011 · 三条成果轨道并行但不共享定义权

- 状态：Accepted
- 日期：2026-08-11
- 背景：项目既需要严谨研究，也需要以作者语言向公众说明问题，并将原则应用于制度；按单线顺序等待会使任何一条都难以获得反馈。
- 决定：研究框架、公众思想书和制度白皮书三条成果轨道并行。研究框架维护当前概念、证据状态和反例；思想书维护公众可读的问题与思想过程；制度白皮书维护应用设计。
- 理由：让表达和制度压力测试尽早反哺研究，同时避免三份互不兼容的理论。
- 后果：思想书或白皮书提出新命题时必须返回研究框架评审；三轨不得静默各自修改核心定义。
- 未采用方案：必须先完成全部理论才写公众稿；让公众稿或应用稿单独成为新的规范来源。

## D-012 · 用户表述与 AI 扩写分别追溯

- 状态：Accepted
- 日期：2026-08-11
- 背景：来源对话中，用户指出 AI 文字常“好像是那个意思”，但专业术语使本人也难以读懂；同时对话的大部分体系和书稿由 AI 扩写形成。
- 决定：用户直接表述、用户粘贴内容、AI 回答和后续重构分别记录。AI 可以辅助结构、术语和反例，但作者不能理解或确认的表述不得作为作者原话或已接受立场。
- 理由：可读性不仅是文风问题，也关系思想归属、概念准确与项目可维护性。
- 后果：公众稿优先使用作者可复述的日常语言；第一人称 AI 扩写在作者确认前保持草稿；事实主张仍需独立核查。
- 未采用方案：因用户允许继续工作，就把后续 AI 文字整体视为作者逐句确认。

## D-013 · 来源案例与制度主张分离

- 状态：Accepted
- 日期：2026-08-12
- 背景：初始长对话同时包含用户问题、用户区块中的混合材料、AI 反例、参数与后续重构；把案例收进项目容易被误读为事实已经发生、机制已经接受或作者已经确认。
- 决定：来源提取和压力测试分别使用 `[U]`、`[UM]`、`[A]`、`[R]` 标记可追溯层级。案例进入 `06_Criticism_and_Failure/` 只表示相应风险必须被检验，不表示案例发生率、被检验机制或建议方案已经成立。
- 理由：压力测试应保留最强反例，同时不能让 AI 生成的场景、解释和解决方案倒签为用户立场或经验事实。
- 后果：每个案例必须另列证据、受影响者、通过条件、停止条件与复测方法；任何机制仍须经过当前框架、资料研究和共同验证。
- 未采用方案：因用户允许继续整理，就把全部对话内容视为已确认方案；因案例未被证明普遍发生，就从项目中删除其压力测试价值。

## D-014 · 区分基本权利、事实权力与授权权限

- 状态：Accepted
- 日期：2026-08-12
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-84E2C1`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受三分结构、不可互相自动推出的边界及其进入现行术语和权力模型；不接受任何未写出的权限分配方案。
- source_ids：`SRC-2F8C4A71`、`SRC-9B1D6E30`
- supersedes：不整体替代既有决定；细化 `D-005` 与 `D-008` 中笼统的“权力 / 权限”表述。
- affected_documents：`README.md`、`CONTRIBUTING.md`、`GLOSSARY.md`、`03_Aletheia_Framework/权力模型.md`、`03_Aletheia_Framework/第一原则.md`、`00_Core_Question/权力与责任.md`、`04_Institution_Design/Political_System/权力来源.md`、`04_Institution_Design/Political_System/权力限制.md`、`04_Institution_Design/Political_System/多中心治理与技术中枢.md`、`DOCUMENT_STATUS.md`。
- unresolved_questions：事实权力如何测量、何时构成支配；不同授权权限的启动、监督、冲突、撤回和救济程序。
- 背景：项目既使用“每个人拥有基本权利”，也分析资源、知识和技术形成的现实控制力，并讨论任务授权。三者若都叫权力，会把权利资格、实际影响和正当执行许可互相偷换。
- 决定：
  1. **基本权利**是人及受影响者不因承担任务才取得的规范资格，包括表达、异议、申诉、请求救济、基本保障与时间自主等程序性和实质性权利；
  2. **事实权力**是无论是否获得正当授权，能够显著或持续地非对称控制他人选项、规则、资源、数据、身份与资格入口、评价、议程或救济可得性的实际能力，不因存在就自动正当；一般说服、偶然影响或平等协商不因产生结果就自动属于事实权力；
  3. **授权权限**是为完成有限任务或履行特定公共职能，经可追溯的正当程序取得、受监督、定期复核并应退出的制度性行动许可。
- 理由：把“拥有影响力”“应被保护”与“被允许执行”分开，才能分别审查事实、正当性、责任和救济。
- 后果：任何文档使用“权力”时须指出属于哪一层；基本权利不以任务授权为条件，事实权力接受审计，授权权限不得从能力、需求或事实控制力自动生成。
- 未采用方案：继续用一个“权力”概念覆盖权利、影响力和权限；把事实控制当作正当授权；把基本权利写成完成任务后获得的许可。

## D-015 · 公共必要性认定、公共组织与维护责任、个人公共义务分层

> **现行术语注记（2026-08-20）：** 以下保留 `D-015` 当时的三层原始确认。`D-018` 将旧第三层“个人公共义务”拆为“有限互惠公共责任”与“具体公共责任任务义务”；`D-028` 又在公共必要性之后补入“公共需求归属责任”。现行分析因此展示为五个判断，原有不得自动跳转边界不变。

- 状态：Accepted
- 日期：2026-08-12
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-84E2C1`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受三层分析结构及第三层保持开放；不确认统一个人公共义务、工时、抽签、处罚或强制方式。
- source_ids：`SRC-2F8C4A71`、`SRC-9B1D6E30`
- supersedes：细化 `D-008` 的责任生成语法；明确取代旧稿把“有公共需要”直接推出“成员有劳动义务”的简写。
- affected_documents：`README.md`、`GLOSSARY.md`、`03_Aletheia_Framework/第一原则.md`、`03_Aletheia_Framework/责任模型.md`、`03_Aletheia_Framework/资源模型.md`、`04_Institution_Design/README.md`、`04_Institution_Design/Labor_System/公共责任制度.md`、`04_Institution_Design/Labor_System/劳动制度白皮书.md`、`04_Institution_Design/Labor_System/任务池.md`、`04_Institution_Design/Labor_System/能力池.md`、`04_Institution_Design/Labor_System/时间制度.md`、`04_Institution_Design/Labor_System/Mechanisms/公共服务连续性与储备机制.md`、`04_Institution_Design/Labor_System/基本保障_有限公共责任_关键服务连续性协调研究.md`、`06_Criticism_and_Failure/基本保障、有限公共责任与关键服务连续性压力测试.md`、`DOCUMENT_STATUS.md`、`ROADMAP.md`。
- unresolved_questions：个人公共义务是否成立；若成立，其来源、对象、必要性、替代、拒绝、补偿、总负担、例外与救济边界。
- 背景：公共服务确有必要、机构承担持续维护责任，以及某个成员因此负有个人义务，是三个不同判断。将它们合并会让系统需要未经论证地占有个人时间。
- 决定：
  1. **公共必要性认定**通过可质疑的公共程序，暂时确认某项共同条件或服务是否必须维护、最低水平、受影响者、替代方案和可接受降级；
  2. **公共组织与维护责任**描述在公共必要性经正当决定后，由明确机构或角色承担的融资、设计、招募、采购、储备、维护、监督、救济和连续性职责；
  3. **个人公共义务**询问个体是否以及在何种条件下负有非自愿承担义务，该命题继续保持 `question`。
- 理由：把事实必要性、机构承诺与个人规范义务分开，才能在不牺牲基本保障和时间主权的情况下研究连续性。
- 后果：不得从公共任务存在、共同体成员身份、受益或具备能力直接推出个人义务；现行应用层须分别说明任务必要性、机构承诺和个人承担的授权来源。
- 未采用方案：把三层统一称为已经成立的“公共责任”；用基本保障交换个人劳动；以系统缺口自动生成个人任务。
- 后续状态（`0.1.6`）：`D-018` 部分取代本决定中“个人公共义务是否成立仍完全开放”的结论，将其细化为已经接受的有限互惠公共责任原则与仍待形成的具体公共责任任务义务；本决定的三层区分及不得自动跳转边界继续有效。

## D-016 · 区分任务生命周期和制度形成与修正循环

- 状态：Accepted
- 日期：2026-08-12
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-84E2C1`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受双循环及其接口；不确认具体公共制度应采用何种投票、代表、审查或执行组织。
- source_ids：`SRC-2F8C4A71`、`SRC-9B1D6E30`
- supersedes：细化 `D-008` 的单线制度生成语法，不否定其目的轴与授权边界。
- affected_documents：`README.md`、`03_Aletheia_Framework/世界观与制度生成语法.md`、`03_Aletheia_Framework/第一原则.md`、`03_Aletheia_Framework/责任模型.md`、`03_Aletheia_Framework/决策模型.md`、`03_Aletheia_Framework/反馈修正机制.md`、`04_Institution_Design/README.md`、`04_Institution_Design/Political_System/权力来源.md`、`04_Institution_Design/Political_System/民主决策.md`、`04_Institution_Design/Labor_System/任务池.md`、`04_Institution_Design/Labor_System/劳动制度白皮书.md`、`06_Criticism_and_Failure/基本保障、有限公共责任与关键服务连续性压力测试.md`、`DOCUMENT_STATUS.md`。
- unresolved_questions：谁能启动制度循环、何种证据允许制度进入试验、任务反馈如何升级为规则修订、紧急任务与常态制度循环怎样衔接。
- 背景：旧的单线箭头容易把一次共同决策、制度规则、具体任务和个人任务承诺压成同一事件。
- 决定：
  - **任务生命周期**处理具体任务从需求说明、公共性与条件审查、任务形成、邀请与承诺、有限授权、执行、交接、退出到修复；
  - **制度形成与修正循环**处理问题进入、受影响者识别、方案比较、公共决定、有限试验、监督、复核、修正、暂停或废止；
  - 制度循环可以规定任务形成条件，任务结果可以反馈制度循环，但任何一步都不自动完成另一循环所需的授权和审查。
- 理由：制度规则的公共正当性与某个人接受一项任务的授权条件不同，必须分别留下责任和退出路径。
- 后果：任务完成不证明制度正当；制度接受也不等于任何个人已经承诺具体任务；任务权限结束不等于维护制度和修复伤害的责任同时消失。
- 未采用方案：用一条无分支流程描述需求、制度、任务和执行；让任务系统自行生成和修改公共规则。
- 后续状态（`0.1.6`）：`D-018` 将本决定中任务形成后的单一“邀请与承诺”路径细化为两个分支：普通任务继续以邀请和本人承诺形成承担依据；公共责任任务则须经事项适配程序形成个案义务，并同时具备相关能力、合理条件、豁免或替代及申诉等边界。此细化不改变双循环及有限授权要求，也不允许从制度接受、成员身份或公共缺口直接推出个案义务。

## D-017 · 角色拆分，并区分项目确认记录与公共决策留痕

- 状态：Accepted
- 日期：2026-08-12
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-84E2C1`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受需求者、受影响者、定义权角色和退出的显式记录，以及两种留痕不可互相替代；不确认现实公共决策的代表或裁决机制。
- source_ids：`SRC-2F8C4A71`、`SRC-9B1D6E30`
- supersedes：细化 `D-011` 至 `D-013` 的定义权和来源治理；不回溯性改变旧决定的确认状态。
- affected_documents：`README.md`、`CONTRIBUTING.md`、`DECISION_LOG.md`、`GLOSSARY.md`、`00_Core_Question/谁代表需求.md`、`03_Aletheia_Framework/需求模型.md`、`03_Aletheia_Framework/决策模型.md`、`03_Aletheia_Framework/反馈修正机制.md`、`03_Aletheia_Framework/世界观与制度生成语法.md`、`04_Institution_Design/Education_System/儿童公共照护与成长自主.md`、`08_Research_Workbench/05_Provenance_and_Decision_Records/`、`DOCUMENT_STATUS.md`、`ROADMAP.md`。
- unresolved_questions：现实公共决策如何确认需求者和受影响者、处理多重身份与沉默、配置定义权、记录异议及建立独立复核。
- 背景：项目发起者确认一项理论方向，只能证明 Project Aletheia 的思想与版本决定；它不能代替现实制度中受影响者的授权。与此同时，只写“公众参与”也会隐藏谁有权命名问题、解释证据和定稿。
- 决定：所有重要机制显式记录需求者、受影响者、定义与分类角色、决定者、执行者、监督和救济者以及退出条件；项目另以 Source ID 和确认记录证明自身决定链。项目确认记录与候选公共决策留痕分别维护、不得互相冒充。
- 理由：思想归属审计与公共权力合法性审计目的不同，必须同时存在又保持边界。
- 后果：Accepted 决定新增确认字段；来源先取得 Source ID；项目内部确认不被写成受影响者同意；公共机制不得只引用项目决定作为实施授权。
- 未采用方案：因用户批准修改项目就声称制度获得公共授权；因记录了公共参与设想就省略项目自身的作者确认与来源追溯。

## D-018 · 基本保障、有限互惠公共责任与互惠性公共运行权益分层

> **现行术语注记（2026-08-20）：** `D-018` 对 `D-015` 的旧第三层作内部拆分；`D-028` 进一步补入公共需求归属责任。当前统一使用公共必要性认定、公共需求归属责任、公共组织与维护责任、有限互惠公共责任、具体公共责任任务义务五个判断。

- 状态：Accepted
- 日期：2026-08-12
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-5E7A91`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受基本保障不与履责挂钩、具备相应现实能力的成员原则上承担有约束力但有限的互惠公共责任、正当理由可支持豁免或延期或替代，以及互惠性公共运行权益可以在严格边界内与履责相关；不确认具体工时、任务分配、记录系统、权益清单或非履责后果。
- source_ids：`SRC-D8C4F2A6`
- supersedes：部分取代 `D-015` 中“个人公共义务是否成立仍完全开放”的结论，并细化 `D-010` 与 `D-016` 把承担依据统一写作“邀请与承诺”的单一路径；保留 `D-010` 的能力数据用途限定、能力不等于义务与不得自动调度边界，保留 `D-015` 的公共必要性认定、公共组织与维护责任、具体个人任务分配三层不得自动跳转，也保留 `D-016` 的双循环与有限授权边界。
- affected_documents：`README.md`、`GLOSSARY.md`、`VERSION.md`、`CHANGELOG.md`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`MIGRATION_MAP.md`、`00_Core_Question/需求与责任.md`、`00_Core_Question/自由与共同体.md`、`03_Aletheia_Framework/第一原则.md`、`03_Aletheia_Framework/责任模型.md`、`03_Aletheia_Framework/资源模型.md`、`03_Aletheia_Framework/世界观与制度生成语法.md`、`04_Institution_Design/README.md`、`04_Institution_Design/Labor_System/公共责任制度.md`、`04_Institution_Design/Labor_System/劳动制度白皮书.md`、`04_Institution_Design/Labor_System/基本保障_有限公共责任_关键服务连续性协调研究.md`、`06_Criticism_and_Failure/基本保障、有限公共责任与关键服务连续性压力测试.md`。
- unresolved_questions：哪些公共条件达到必要性门槛；哪些成员具有何种相关现实能力；正当理由、豁免、延期与替代怎样认定和复核；具体任务的工时、风险、分配、补偿、退出与申诉；记录的最小字段、期限与删除；哪些互惠性公共运行权益可与何种履责直接关联、何种后果相称以及如何恢复。
- 背景：`D-015` 正确阻止了从公共需要直接跳到个人派工，但把第三层整体保持开放，尚未回答项目是否接受任何有约束力的成员互惠责任。用户本轮明确选择：基本保障与基本权利不因逃避责任消失，同时具备相应现实能力的成员原则上应公平分担维持公共必要条件的有限责任。
- 决定：
  1. **基本保障与基本权利不与履责挂钩。** 食物、住所、基础医疗、教育、人身安全和必要服务等基本保障，不得因拒绝、未履行或逃避互惠责任而取消；表达、异议、申诉、请求救济和人格尊严等基本权利同样不消失。
  2. **接受有限互惠公共责任原则。** 具备相应现实能力的成员，原则上对维持经正当程序确认的公共必要条件承担有约束力但有限、公平且可审查的分担责任。责任不能扩张为共同体对个人全部时间、身体、能力或人生方向的所有权。
  3. **正当理由可以改变承担方式。** 健康、年龄、照护、能力限制、心理健康、创伤、安全、隐私及其他经公平程序认可的理由，可以支持豁免、延期或替代承担；不得把无法承担、合理拒绝或提出申诉称为逃避。
  4. **原则义务不自动生成具体派工。** 具体公共责任任务义务只有在公共必要性、机构先行责任、分配公平、本人相关能力、合理任务条件、替代或豁免、独立申诉及事项适配程序均成立后，才能形成。能力登记、成员身份或公共缺口都不能单独自动派工。
  5. **互惠性公共运行权益可以有限关联。** 高于基本权利和基本保障底线、且与公共协作直接相关的非基本权益，可以在严格相关、相称、限期、可申诉并具有明确恢复程序时与履责相关；允许建立关联不等于任何具体清单或后果已经被接受。
  6. **逃避互惠责任只评价行为。** 它只指具备相关能力且长期、无正当理由拒绝任何合理分担的行为，不是固定人格、身份等级或取消基本权利的依据。
- 理由：把不可取消的人格与保障底线、有边界的成员互惠责任、具体任务程序和非基本公共协作权益分开，既避免把公共服务成本永久外包给承担者，也避免用生存资格、人格污名或无限派工强迫合作。
- 后果：`公共责任制度.md` 可由“责任是否存在”的问题稿转为承载已接受原则与开放机制的 `draft`；协调研究仍保持 `question`。任务生命周期须区分普通任务的邀请与承诺分支，以及公共责任任务经事项适配程序形成个案义务的分支；两者随后取得的都只是范围、期限和退出条件明确的有限授权。后续设计必须把正当理由、机构先行责任、公平分配、能力相关性、申诉与恢复写入任务和权益关联程序。
- 未采用方案：固定公共责任工时；按年龄或能力抽签派工；责任积分、总诚信分或终身责任账本；以拒绝或未履责扣减基本保障或基本权利；能力池自动调度；用单一处罚替代正当理由、替代承担与申诉；从公共缺口直接生成个人任务。

## D-019 · 接受 v0.2.0 四十四项架构与制度接口方向

- 状态：Accepted
- 日期：2026-08-13
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-A20F44`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受 `PROJECT_INITIATOR_CONFIRMATION_v0.2.0.md` 中 A1—H4 共 44 项作为当前研究或规范方向；不确认现实法律效力、实施参数或制度效果。
- source_ids：`SRC-73475D63`、`SRC-7EBEDFD7`、`SRC-3A1F7903`、`SRC-2061DD36`、`SRC-4C7E9A12`
- supersedes：把 v0.2.0 中“新增方向待项目发起者逐项确认”的状态更新为“方向已接受、实现仍待验证”；不取代 `D-018` 的保障和有限互惠责任边界。
- affected_documents：Architecture Map、Module Dependency Graph、Open Problems List、权力转换审计模型、制度接口原则、宪制司法、授权任务型行政、公共财政、公共信息与 AI、激励制度、压力测试协议及根治理文件。
- unresolved_questions：具体投票和修宪程序、法院组成、紧急期限、行政组织形式、预算与税制参数、数据访问等级、AI 技术方案、贡献回报参数及各机制的现实验证。
- 背景：v0.2.0 从新制度对话中整理出 44 项可独立判断的方向命题，并明确区分项目接受、现实授权和经验验证。
- 决定：44 项全部接受，成为 Aletheia 当前方向。项目进入术语回归、模块接口审计和压力测试阶段，暂不继续增加大模块或提前确定实施参数。
- 理由：逐项确认消除了 AI 整理内容与项目发起者真实方向之间的归属不确定性，同时保留机制验证空间。
- 后果：生成 v0.2.1；相关框架和制度文件继续保持 `draft`，开放问题和未验证实现保持 `question`；后续修改必须记录替代关系。
- 未采用方案：把整段聊天自动视为作者确认；把方向接受等同于现实制度有效；立即编写完整法典、算法和数值参数。

## D-020 · 接受职业开放、司法四层与生育婚姻亲职分离三十七项方向

- 状态：Accepted
- 日期：2026-08-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-C35F82`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受 `PROJECT_INITIATOR_CONFIRMATION_v0.2.2.md` 中 P1—P10、J1—J11、F1—F12、S1—S4 共 37 项作为当前研究或规范方向；不确认原 RTF 全文、具体参数、现实法律效力或制度效果。
- source_ids：`SRC-9F4B2C71`、`SRC-1D6A8E43`
- supersedes：不整体取代既有决定；细化 `D-014` 的能力与权限边界、`D-019` 的司法与制度接口方向，并为职业入口和家庭儿童专题新增已确认方向。
- affected_documents：`GLOSSARY.md`、`03_Aletheia_Framework/第一原则.md`、`04_Institution_Design/Shared_Mechanisms/职业入口开放、能力分级与任务授权原则.md`、`04_Institution_Design/Constitutional_and_Legal_System/宪制与司法原则.md`、`04_Institution_Design/Constitutional_and_Legal_System/司法资格、岗位与案件授权分离机制.md`、`04_Institution_Design/Education_System/儿童公共照护与成长自主.md`、`04_Institution_Design/Education_System/生育、婚姻、亲职与儿童保障分离原则.md` 及治理、导航与发布文件。
- unresolved_questions：资格标准、训练容量、岗位选择、任务记录、司法组织、随机分案、法院构成、刑罚、初始亲职、儿童参与、公共育幼、家庭介入、记录期限和全部实施参数。
- 背景：用户进一步明确，所谓取消职业门槛是取消与专业能力和责任无关的身份、路径和人数限制；法院职能需要常设，但资格、岗位和案件权限必须分开。同时，用户从公共育幼讨论中提出生育与婚姻分离，并把物理人身安全置于最高保护层级。
- 决定：接受三个专题压缩稿的 37 项方向。专业资格原则上不以岗位名额限量；岗位可以按真实需求有限；能力、资格、岗位、责任与授权分别成立。司法采用法院常设、资格开放、岗位有限、案件逐项授权的研究结构。每个人的生命、身体完整、性自主和现实人身安全进入最高保护层级，但刑事责任仍须分级和遵守证据程序。生育、婚姻、亲职与儿童权利分别处理，公共育幼分担照护压力而不取得儿童所有权。
- 理由：这些方向把用户对名额垄断、职业身份权力、司法连续性、身体安全、婚姻生育绑定和儿童占有的担忧转化为与现行能力—资格—权限边界兼容的框架命题。
- 后果：生成 v0.2.2；三份专题进入应用层 `draft`，具体等级、分数、刑罚、机构、记录和参数继续保持开放并须经过资料研究、受影响者参与和压力测试。
- 未采用方案：能力直接产生权限；取得资格自动获得岗位；法官身份拥有全部案件；原始卷宗无条件公开；所有身体损害一律同刑；国家许可生育或拥有儿童；亲职总信用分；把原 RTF 全文自动升级为项目结论。

## D-021 · 接受个人需求责任与共同脆弱性下的非等级互助原则

- 状态：Accepted
- 日期：2026-08-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-C49CCC`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受个人需求责任、共同脆弱性、非等级互助、跨时间传递、基本照护不作功劳结算和不制造感恩服从，作为当前规范方向；不确认具体照护机构、资源参数、互助积分或法律强制方式。
- source_ids：`SRC-8D4F2B90`、`SRC-C49CCC9B`
- supersedes：把 `D-014` 和现行责任模型中的“说明责任”扩展为更完整的个人需求责任；补充 `D-018` 的有限互惠公共责任为何不应建立在弱者等级、逐人功劳结算或感恩服从上，不取代基本保障与任务程序边界。
- affected_documents：`GLOSSARY.md`、`03_Aletheia_Framework/第一原则.md`、`需求模型.md`、`责任模型.md`、`04_Institution_Design/Labor_System/公共责任制度.md`、`基本保障_有限公共责任_关键服务连续性协调研究.md` 及治理、来源和导航文件。
- unresolved_questions：如何判断合理自助与真实渠道可及性；私人协作、公共服务和紧急救助如何分别响应；怎样承认照护与帮助贡献而不建立功劳等级；非家庭化、非强制的跨时间互助如何组织；关系性需要中公共制度能提供什么而不能强迫什么。
- 背景：现行“说明责任”只要求请求协作时说明条件，未充分表达个人应在现实能力范围内积极参与解决自身需求。原对话同时提出，衰老、疾病、残障与失能是任何人可能进入的处境，帮助不应被叙述为高位者对低位者施舍，而应理解为共同体成员为自己与家人也可能需要的未来互助条件作出接续。
- 决定：建立个人需求责任，包含合理自助、求助、维权、配合、减损和说明；其完成情况可以影响协作方式、响应顺序、替代和相称费用，但不取消表达、基本权利、基本保障与紧急救助，也不免除其他责任主体。建立共同脆弱性与非等级互助原则：帮助跨时间、对象和生命阶段传递，基本照护不作逐人功劳结算，贡献须被承认但不产生人格债务、永久还债或服从义务。
- 理由：这使“个人不把可承担部分全部外包”与“社会不抛弃无法承担者”同时成立，并把帮助关系从固定强弱身份转为处境可变的平等互助；它也为有限互惠公共责任提供不依赖生存交换、功绩资格和弱者污名的价值基础。
- 后果：生成 v0.2.3；第一原则新增共同脆弱性公理，需求与责任模型扩展个人需求责任，劳动模块补充非等级互助基础。后续须用医疗、劳动维权、残障支持、养老与长期照护案例检验可行自助、渠道障碍、机构责任和关系性需要边界。
- 未采用方案：谁有需求谁独自承担全部责任；得不到帮助都归咎需求者；过去未贡献者失去基本照护；精确互助积分和终身功劳账本；强制情感感谢；接受帮助产生服从；把老人、病者和残障者固定为低等弱者；用个人需求责任免除侵害者或机构责任。

## D-022 · 接受公共权力失效纠错与公共合作激励方向

- 状态：Accepted
- 日期：2026-08-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-7B4D2E`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受 `PROJECT_INITIATOR_CONFIRMATION_v0.2.4.md` 中 G-01—G-20、C-01—C-14 按建议状态成立；不确认原 RTF 与粘贴稿全文、实施参数、现实法律效力或效果。
- source_ids：`SRC-5A8E1C42`、`SRC-B79D3F06`、`SRC-41C7A9D2`
- supersedes：不整体取代既有决定；扩展 `D-014` 的权力限制与事实权力审计、`D-016` 的项目退出后修复责任、`D-019` 的司法行政财政和激励接口，并保持 `D-018` 的基本保障与有限公共责任边界。
- affected_documents：`03_Aletheia_Framework/第一原则.md`、`责任模型.md`、`04_Institution_Design/Political_System/权力限制.md`、`民主决策.md`、`公共权力失效纠错机制.md`、`Administrative_System/授权任务型行政.md`、`Public_Finance/任务预算与公共资源.md`、`Constitutional_and_Legal_System/宪制与司法原则.md`、`Incentive_System/激励反等级原则.md`、`公共合作激励与参与保障.md` 及治理、来源、状态、路线图和发布文件。
- unresolved_questions：调查与保全门槛、替代调查组成、证据托管技术与访问、基金规模和偿付、追偿时效与重新开始、利益增量计算、资产范围、参与成本参数及困难必要劳动的供给效果。
- 背景：前轮审计发现，正常授权和监督原则尚不足以处理掌权者控制证据、监督机构被俘获、责任人无力赔偿和掌权者从错误项目获利；合作激励也需要说明合作为何对个人值得，同时保护拒绝、异议和举报。
- 决定：建立公共权力失效纠错候选框架，使决定、证据、监督、修复和利益保持可相互纠错；建立公共合作激励与参与保障框架，以需求改善、时间、安全、服务、现实补偿、实际影响和反报复为核心，具体程序便利只复用限定事实，不形成综合信用。
- 理由：制度不能只描述正常运行，还要在监督、赔偿和利益约束失效时具有恢复路径；合作也不能靠忠诚、基本保障条件化或人格等级维持。
- 后果：生成 v0.2.4；新增两份 `draft`，同步责任、司法、政治、行政、财政和激励接口。五层纠错与困难劳动供给继续验证，不写成已完成制度。
- 未采用方案：债务劳动；统一责任积分或补偿总分；综合可靠度或总诚信分；项目失败自动推定腐败；无限范围证据库、搜查、资产冻结或终身追责；让调查者按追回金额获利。

## D-023 · 接受十环节权力集中控制矩阵方向

- 状态：Accepted
- 日期：2026-08-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-9C2F61`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受十环节、三级风险、组合触发、利益贯穿、质量与投诉独立及紧急退出方向；具体阈值、组织和效果保持 `draft`。
- source_ids：`SRC-E4A91C72`
- supersedes：不取代既有权力三分、授权封套和五层纠错；把 `D-022` 的“不得同时控制决定、证据、监督、修复和利益”展开为可审计环节与自动动作。
- affected_documents：`GLOSSARY.md`、`03_Aletheia_Framework/权力模型.md`、`权力转换审计模型.md`、`04_Institution_Design/Political_System/权力限制.md`、`公共权力失效纠错机制.md`、`十环节权力集中控制矩阵.md`、`Administrative_System/授权任务型行政.md` 及治理、导航和发布文件。
- unresolved_questions：不同风险和规模的触发线、关联控制网络证据、现场质量独立条件、外部审计组成、暂停权限、紧急例外、服务连续性和防止程序瘫痪。
- 背景：项目已限制正式权限并建立失效纠错，但缺少一张把过程控制集中自动转化为回避、审计和拆分的统一矩阵；项目管理、信息、质量、投诉和监督可能在没有最高职位的情况下形成事实掌权节点。
- 决定：对公共事项绘制十环节控制图，把重大利益作为贯穿层；高风险组合自动触发复核，三个及以上实质独立环节原则上触发外部审计和权限拆分，四个及以上或关键组合采用更强制纠偏。调查与裁判、执行与最终质量、执行与唯一投诉入口保持分离。
- 理由：权力集中应按真实控制网络和流程节点识别，而不是只看正式职位或机构数量；自动动作使“原则上分离”具有可操作后果。
- 后果：生成 v0.2.5；新增矩阵 `draft`，同步权力和行政接口。阈值不视为经验验证完成，也不形成权力或腐败总分。
- 未采用方案：责任自动生成权限；按机构名称假定分权；正常工资自动构成腐败；调查者兼任高后果最终裁判；执行者最终自证；无限增设常设机构；紧急合并永久化。

## D-024 · 用责任会计三分结构取代 C-13

- 状态：Accepted
- 日期：2026-08-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-6D2A8F`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受周期性基础责任账户、公共贡献履历与领域限定的专业可靠性档案三分结构，把反等级从拒绝衡量改为限制衡量结果的用途；不确认具体公式、周期、达标线、权益清单或后果参数。
- source_ids：`SRC-6D2A8F31`
- supersedes：正式取代 `D-022` 所确认的 v0.2.4 逐项表 `C-13` 中“删除责任积分，不以积分记录或激励合作”的全面禁止；不取代 `D-018` 的基本保障、具体任务程序和有限互惠责任边界，也不取代 `D-022` 对债务劳动、综合可靠度和总诚信分的拒绝。
- affected_documents：`README.md`、`GLOSSARY.md`、`03_Aletheia_Framework/第一原则.md`、`责任模型.md`、`04_Institution_Design/Labor_System/公共责任制度.md`、`劳动制度白皮书.md`、`Incentive_System/激励反等级原则.md`、`公共合作激励与参与保障.md`、`责任积分、贡献积分与领域专业评价.md` 及治理、来源、导航和压力测试文件。
- unresolved_questions：责任当量公式、结算周期、达标线、能力与照护调整、证据口径、公开范围、记录期限、补足程序、非基础互惠性公共运行权益的候选范围和未履责后果，以及刷分、定价权俘获、隐性负担漏算和关键服务覆盖失败。
- 背景：v0.2.4 为防止等级化而全面删除责任积分，但也同时削弱了公平份额比较、反搭便车、普通贡献可见和专业协作的制度工具。
- 决定：建立三类目的和数据边界不同的记录。周期性基础责任账户处理当期合理份额与负担结算；公共贡献履历记录可验证的日常与额外贡献；领域限定的专业可靠性档案支持特定领域的任务匹配和专业判断。三者不得合成公民总分。
- 理由：公平不是不比较，而是在相同的责任成立、调整、豁免、折算和申诉规则下比较经调整的合理份额。一个制度需要可量化的责任会计和贡献可见性，但无需将人的整体价值标价。
- 后果：生成 v0.2.6；新增三分结构 `draft`，同步术语、第一原则、责任、劳动、激励与压力测试。责任会计不替代关键服务供给规划，也不证明任何具体参数可行。
- 未采用方案：无记录地依赖自发善意；统一终身责任或贡献总分；人格、忠诚或总诚信评分；积分购买基本保障或政治权力；专业声誉跨领域自动产生权威；仅凭未达标自动派工、公开羞辱或累加责任债务。

## D-025 · 采用年度责任积分、领域累计贡献与专业参考摘要

- 状态：Accepted
- 日期：2026-08-16
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-A2D7F9`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受年度基础责任积分、按领域累计的贡献积分、领域质量评价和由证据生成的领域专业参考指数；接受日常维护与重大成果均进入记录；不确认具体数值、算法、权益清单或现实法律效力。
- source_ids：`SRC-A2D7F914`、`SRC-CE7F7BC6`、`SRC-476C8C48`
- supersedes：细化 `D-024`。保留责任、贡献和专业证据分账及限制用途，取代“不恢复任务系数”和“不允许任何累计贡献总量”的过宽限制；不恢复旧版固定参数、抽签、自动派工、总诚信分或人格等级。
- affected_documents：`GLOSSARY.md`、`03_Aletheia_Framework/第一原则.md`、`04_Institution_Design/Labor_System/公共责任制度.md`、`Mechanisms/有限互惠公共责任机制.md`、`Incentive_System/责任积分、贡献积分与领域专业评价.md` 及治理、来源、导航和状态文件。
- unresolved_questions：年度参考时数、个人额度调整、认可时间、任务系数维度与上下界、完成比例、领域分类、累计总量界面、质量算法、专业参考指数有效期、证据、隐私、补足、互惠性权益和未履责后果。
- 背景：`D-024` 恢复了责任衡量，却仍把公式、任务系数和累计总量全部排除。项目发起者进一步明确，责任积分用于防搭便车，贡献积分用于使普通和重大贡献可见并引导公共价值，领域质量和专业参考用于把专业影响从财富、职位和流量转向实际证据。
- 决定：年度基础责任采用普通条件参考额度，经个人现实能力和处境调整；具体任务按“认可时间 × 任务责任系数 × 完成比例”的结构结算并年度清零。已完成任务同时进入相应领域的长期贡献积分；贡献可以有累计总量入口，但必须同时展示领域构成、时间、质量和来源。领域质量按任务类型建立；领域专业参考指数只作相关证据摘要，不独立累计或生成权限。
- 理由：同一分数无法同时处理当期公平、历史贡献、专业质量和快速认知。分账可以防搭便车并使持续维护可见，摘要层又满足普通人需要简单入口的现实，而用途限制防止衡量滑向生存资格、人格总分和跨领域统治权。
- 后果：生成 v0.2.7；新增《有限互惠公共责任机制》并修正来源 RTF 中“取消责任积分”的冲突；《第一原则》增加评价与支配分离、自愿影响力和日常维护可见；现行激励文件升级为三套记录、四层功能。
- 未采用方案：只有重大成果才记分；只记录失败而忽略长期正常维护；把实际耗时无限计分；以高贡献抵销伤害；仅凭未达标自动认定搭便车；声誉指数自动产生决定权或跨领域权威；把私人思想和全部生活选择纳入公共积分。

## D-026 · 分离文档成熟度与验证进度并建立三模型交叉审计

- 状态：Accepted
- 日期：2026-08-16
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-5E32B8`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受独立验证状态维度和权力—责任—决策交叉一致性表；接受把事实权力的实际控制责任显式写回责任模型，并把公共决定、具体责任分配和执行授权在决策出口分开。
- source_ids：`SRC-5E32B8C1`
- supersedes：不取代原有 `stable/draft/question/template/archive` 文档状态；增加与其正交的验证进度。不取代权力、责任或决策模型的定义，只增加交叉审计入口并修复发现的接口遗漏。
- affected_documents：`CONTRIBUTING.md`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`03_Aletheia_Framework/权力模型.md`、`责任模型.md`、`决策模型.md`、`权力_责任_决策交叉一致性表.md` 及治理、来源和导航文件。
- unresolved_questions：验证状态按何种证据升级；参与者招募、伦理保护、代表性和退出怎样记录；三模型接口如何在公共项目、紧急事项和小型组织中复测；验证登记是否需要未来拆成独立数据表。
- 背景：v0.2.7 的 `draft/question/template` 只能表示文档成熟度，不能区分缺论证、已有方案待验证和缺不可替代外部参与者。三个核心模型总体兼容，但责任模型没有直接连接事实权力归责，决策流程也可能被误读为一次决定同时完成个人任务分配和授权。
- 决定：建立 `not-required`、`not-ready`、`ready-for-validation`、`participant-blocked`、`in-validation`、`partially-validated`、`needs-replication`、`validated-for-current-scope` 验证状态词表，并集中登记具体验证单元。新增三模型交叉表，按触发、责任、授权、事实控制、监督、退出和修复逐阶段核对。
- 理由：完成度必须同时显示“写到了哪里”和“现实检验到了哪里”。把两者混为一个状态会让扩写文字看起来像验证进展，也会让暂缺参与者的问题误显为普通写作待办。交叉表则能在不制造新定义源的前提下暴露模型接口遗漏。
- 后果：生成 v0.2.8；首批十一项验证单元取得初始状态和下一步；责任模型增加按实际控制归责接口，决策模型明确三类输出；交叉表保持 `draft` 并进入现实场景复测。
- 未采用方案：给全部文件机械添加验证标签；从 `draft` 自动推导验证进度；把 AI 审阅、作者确认或内部一致性当作现实验证；把暂缺参与者写成永久不可解决；让交叉表成为第四套权力责任定义。

## D-027 · 用边界案例、探索稿和原典优先级推进验证

- 状态：Accepted
- 日期：2026-08-16
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-9F3A72`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受从两个边界明确的历史案例开始完整分析、形成明确标注的外部探索稿和反馈登记、按对第一原则的实际支撑关系安排原典核查；不确认具体案例正文、发布平台或尚未发生的反馈。
- source_ids：`SRC-9F3A72C4`
- supersedes：不取代 `D-026` 的验证状态和交叉审计；把其中“收窄案例、建立公开反例记录”的下一步转为具体工作，并改变一次补完历史类别或哲学目录的工作顺序。
- affected_documents：`05_Case_Studies/`、`07_Writing/External_Discussion/`、`08_Research_Workbench/07_Validation_Records/`、`01_Philosophy/原典核查优先级.md` 及版本、来源、状态和导航文件。
- unresolved_questions：外部发布平台与链接、反馈代表性和回写结果；两案缺失主体与跨案例复现；第一批原典版本、段落、解释分歧和具体修订。
- 背景：宽泛的“原始社会”和“社会主义实验”没有足够清楚的地域、时间、群体和机制边界；公众讨论虽已可开始，却缺少正式反馈记录；哲学目录的原典核查也不应机械平均推进。
- 决定：选择多贝地区 Ju/’hoansi 与蒙德拉贡法戈尔危机，按统一模板同时记录支持、反例、证据限制与不可复制条件；形成讨论公共决定、责任分配和执行授权三步分离的探索稿；建立外部反馈登记；原典核查按直接性、当前暴露和下游影响排序。
- 理由：验证需要可反驳的对象、稳定来源和明确适用范围。具体案例比时代标签更能暴露机制代价；公开讨论只有留下可追溯反馈和实际修订才构成验证；原典核查应优先降低当前论证风险。
- 后果：生成 v0.2.9；历史案例层取得两个具体 `draft` 并进入有限样本验证；探索稿完成但在取得平台链接前不标为已发布；哲学核查形成分批队列。
- 未采用方案：用单一民族志代表全部早期社会；用一个合作社危机评价全部社会主义；把组织自报当作独立审计；预填正面反馈；把公开评论当作受影响者授权；按目录一次补完哲学史；以哲学家权威替第一原则证明。

## D-028 · 第一责任随需求归属，公共需求由公众承担第一责任

- 状态：Accepted
- 日期：2026-08-20
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-A18D8A`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受“先判断需求归属主体，再判断第一责任”的上位原则；接受公共需求由公众承担归属层第一责任、私人需求仍首先归个人，以及需求体验者、表达者和执行者不必然是第一责任主体。固定需求分类、完整角色责任表、公共需求充分条件和实施机制不在确认范围内。
- source_ids：`SRC-4B788D7F`、`SRC-2622ABAF`
- supersedes：细化 `D-005` 的“需求不直接产生支配权”；修正 `D-021` 可能被误读为先把所有需求套入个人需求责任的解释；在 `D-015`、`D-018` 的公共责任结构中增加公共需求归属责任。历史决定原文、基本保障解绑、机构先行、有限互惠及具体任务不得自动生成的边界继续有效。
- affected_documents：`GLOSSARY.md`、`00_Core_Question/需求与责任.md`、`03_Aletheia_Framework/需求归属与公共需求责任.md`、`需求模型.md`、`责任模型.md`、`第一原则.md`、`04_Institution_Design/Labor_System/公共责任制度.md`、`Mechanisms/有限互惠公共责任机制.md`、公众总纲及治理、来源、状态和导航文件。
- unresolved_questions：公共需求的必要与充分条件；复合需求怎样拆分；组织和角色需求的归属；公众边界；公众第一责任怎样转化为可追溯机构责任；当下求助者的具体交互责任；各领域的最低公共范围与资源、分担和救济机制。
- 背景：此前项目已经区分个人需求责任、机构维护责任、成员有限互惠责任和具体任务义务，却没有显式回答“这项需求究竟属于谁”。医疗例子因此容易把病人作为需求体验者，误写成维持公共医疗系统的第一责任主体；之后再补医生、医院和患者的职责，也无法修复归属层的错位。
- 决定：第一责任定义为需求归属层的首要承接责任，不跟随表面提出者、当下受难者、最有能力者或执行者自动移动。私人需求首先归个人；公共需求主张须经公共正当性判断，成立后公众第一责任随需求归属成立。现行公共责任统一展示为五项分别说明的内容：公共必要性认定、公共需求归属责任、公共组织与维护责任、有限互惠公共责任、具体公共责任任务义务。第一项确认公共需求后，第二项是定义性归属结果；它不自动确定后三项或执行权限，权限继续另行授权。
- 理由：需求体验、需求归属、组织承接和具体执行处在不同层次。把第一责任放回需求归属主体，可以同时阻止公共医疗等共同需要被推回给病人，也阻止私人偏好或组织利益因被表达而自动公共化。
- 后果：新增《需求归属与公共需求责任》作为独立 `draft`；术语、第一原则、需求与责任模型和劳动制度入口同步增加归属层；根 README 与普通读者总纲用普通语言说明“私人需求个人先负责，公共需求公众先负责”；既有四层机制边界扩展为五层显示，历史记录不倒改。
- 未采用方案：谁最先求助谁第一负责；谁正在痛苦谁负责公共系统缺口；公众第一责任等于每名成员承担相同任务；能力或专业身份自动产生执行义务；把共享对话里的 AI 分类和角色表整体标为作者结论；把所有人可能需要当成公共需求的唯一充分条件。

## D-029 · 确认七条公众核心命题与五篇思想书中心

- 状态：Accepted
- 日期：2026-08-23
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-B60C2F`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：确认《项目总纲》第二节当前七条命题作为唯一一套对外普通语言核心命题，并确认五篇思想书候选正文的中心问题；确认有限、有约束力的公共责任个案继续保留为待研究候选，不升级为已经采用或验证的机制。
- source_ids：`SRC-B60C2F17`
- supersedes：不取代既有理论决定；补充现行公众表达与作者审阅状态。`D-018`、`D-028` 的公共责任边界继续有效，候选机制的验证资格不变。
- affected_documents：`07_Writing/Project_Overview/项目总纲.md`、`07_Writing/Thought_Book/` 五篇候选正文与 README、`04_Institution_Design/Project_Aletheia_制度白皮书.md`、`04_Institution_Design/Project_Aletheia_机制层总览草案.md`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`CHANGELOG.md` 及来源确认记录。
- unresolved_questions：总纲其他段落、五篇正文具体措辞和第一人称的逐段确认；相关事实核查；机制竞争方案、触发条件、分配程序、补偿、豁免、退出、申诉、停止线和现实效果。
- 背景：项目已经形成七条公众命题、五篇思想书正文和机制层候选分支，但作者确认状态仍统一显示为 `pending`，无法区分“中心方向已经确认”与“全文尚未逐段审阅”。
- 决定：七条公众命题继续作为根 README、项目总纲、白皮书与公众写作共用的表达基线；五篇思想书的中心问题属于作者希望继续讨论的方向。公共需求成立且公众与机构先行责任已经履行后，正常岗位与自愿承诺仍不足时，有限、可申诉、有补偿和退出条件的有约束力公共责任个案继续留在候选机制集中；现行机制中另有的豁免、延期和替代等保护边界保持原状态，不因本轮确认扩大或缩小。
- 理由：中心确认应当能够跨文档复用，同时又必须与逐句作者确认、事实核查、现实参与和机制验证分开。保留候选允许项目比较替代方案，不等于提前接受强制机制。
- 后果：相关文稿的 `author_review` 更新为 `partial` 并记录确认范围；所有文稿继续保持 `draft`，事实核查继续 `pending`，白皮书与机制层验证状态继续 `not-ready`。
- 未采用方案：把“全部同意”解释为整份总纲、白皮书或第一原则逐句批准；把五篇中心确认解释为现有第一人称和事实主张全部属于作者；把“保留候选”解释为一般个人义务、具体派工、处罚方案、实施授权或现实有效性已经成立。

## D-030 · 冻结 Aletheia 第一原则 v1.0 的规范语义

- 状态：Accepted
- 日期：2026-08-25
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-4D7A31`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：冻结《第一原则》现有十一项核心公理与禁区的规范语义，形成“Aletheia 第一原则 v1.0”；本轮人生周期、公共责任缺席后果、亲职福利、司法接口、计量参数和外部验证细节明确排除。
- source_ids：`SRC-6B2F8E71`
- supersedes：不取代任何既有原则决定；把截至 `D-029` 已形成的十一公理与禁区固定为可追溯语义基线。后续新增或实质修改必须另建决定并说明版本变化。
- affected_documents：`03_Aletheia_Framework/第一原则.md`、`03_Aletheia_Framework/第一原则_v1.0_语义冻结.md`、`03_Aletheia_Framework/README.md`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`PROJECT_INDEX.md`、`CHANGELOG.md` 及来源确认记录。
- unresolved_questions：公理的事实支撑、反例、适用范围和跨场景验证；推论、形成问题、制度生成入口与机制接口的继续修订；未来何种变化构成 `v1.1` 或 `v2.0`。
- 背景：第一原则已经形成十一项公理和成组禁区，但此前 `draft` 状态无法区分“规范方向仍可随时漂移”与“经验、推论和机制仍待验证”。本轮又同时提出人生周期、司法解释和缺席后果，必须防止下游方案随原则一起被误冻结。
- 决定：以《第一原则》现有十一项公理和全部禁区为唯一冻结对象。冻结表示项目在当前范围内以这些规范语义作为稳定上游基线；不表示公理是科学定律、现实法律、公共授权或已验证制度，也不冻结文字润色、链接、证据补充和明确排除的下游机制。
- 理由：稳定的上游边界可以减少下游文件反复漂移；把语义冻结与事实验证、机制采用和实施授权分开，又能保留反例修订和现实检验空间。
- 后果：`第一原则.md` 在其冻结范围内转为 `stable`，另建语义冻结记录；十一公理和禁区外的内容继续按原有命题层级研究，所有本轮机制草案保持 `draft/not-ready`。
- 未采用方案：把整份《第一原则》的每句说明都冻结；把稳定状态写成哲学或经验上的最终真理；将缺席处分、福利范围、亲职条件、司法程序、积分公式、任务时长或验证结果纳入 v1.0。

## D-031 · 建立司法解释接口、人生周期走查与首轮外部验证边界

- 状态：Accepted
- 日期：2026-08-25
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-E9C2B5`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受建立“四种解释方法＋贯穿式主体接口”的司法解释草案；按 40 岁转行、18 岁转衔、80 岁照护、出生与亲职的顺序建立内部走查；把公共责任缺席后果另列候选机制；首次外部验证只准备 40 岁转行三方案复核，生育只允许法律、伦理和匿名情境评审。
- source_ids：`SRC-6B2F8E71`
- supersedes：不改变司法组织四层、既有生命阶段原则或有限公共责任定义；只增加研究接口、走查顺序和验证范围。缺席后果继续受 `D-018`、`D-025` 的未决参数边界约束。
- affected_documents：`04_Institution_Design/Constitutional_and_Legal_System/司法解释体系.md`、`06_Criticism_and_Failure/Lifecycle_Walkthroughs/`、`04_Institution_Design/Labor_System/Mechanisms/公共责任缺席与后果_候选机制.md`、`08_Research_Workbench/07_Validation_Records/External_Validation_Plans/40岁转行_首次外部验证方案.md` 及相关导航、状态、路线图和来源记录。
- unresolved_questions：司法解释方法的冲突权重与案件记录格式；四份走查的作者审阅和事实核查；缺席分类、证据、后果白名单和救济；40 岁转行首轮地域、就业类型、邀请材料、同意与记录协议；生育场景的独立法律伦理复核。
- 背景：项目已经具备规范地基和候选机制总览，但仍缺少从人的完整生命阶段检查制度接口的统一走查；外部评论也要求固定现制基线、比较代价并由现实角色复核。生育场景具有不可逆、隐私和歧视风险，不适合成为首轮现实试验。
- 决定：司法解释采用文字、整体结构、规范目的和现实后果四种方法，主体接口贯穿四法而不构成第五种解释法或司法组织第五层。四份人生周期材料只作内部假设走查。缺席与后果独立成候选机制，不进入第一原则。首次外部验证聚焦 40 岁转行，固定同一基线并比较现制、局部修补和 Aletheia 候选，由五类现实角色复核；生育仅作法律、伦理和匿名合成情境评审，禁止现实制度试验。
- 理由：把规范、解释、机制、内部走查和外部验证分开，可以在不提前实施高风险方案的情况下暴露接口冲突；从风险较低、可撤回的转行场景开始，也比以儿童和生育作为首轮实验对象更符合停止线。
- 后果：新增一份司法草案、四份生命周期走查、一份缺席候选机制和一份拟议外部验证方案；所有新增研究对象均保留 `draft/not-ready` 或 `proposed-unstarted`，不因本决定获得现实效力。
- 未采用方案：把主体接口称为第五种解释法；把内部走查称为验证；从年龄、亲属、能力或行业身份自动产生义务；把福利、处分或亲职条件写入第一原则；向真实生育者、儿童或家庭试运行未经法律伦理审查的制度。

## D-032 · 发布 v0.3.0 公共研究快照并单列反馈后三步稿

- 状态：Accepted
- 日期：2026-08-25
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-C47D91`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：接受把截至本轮已登记的项目状态作为 `v0.3.0` 公共研究快照发布；接受《一个公共事项，为什么要分成三步？》作为反馈后探索稿随 GitHub 快照公开并单列 `PUB-2026-003`。发布不等于全文作者批准、事实核查、现实验证、知乎重发或实施授权。
- source_ids：`SRC-8F6C3A21`
- supersedes：不取代任何理论或机制决定；只结束本轮 `Unreleased` 发布准备，并补充 `D-027` 的公众稿发布史。`PUB-2026-001`、`PUB-2026-002` 及其历史快照继续保留。
- affected_documents：`VERSION.md`、`README.md`、`CHANGELOG.md`、`RELEASE_CHECKSUMS.md`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`07_Writing/External_Discussion/`、`08_Research_Workbench/07_Validation_Records/`、本确认文件及相关来源、状态和导航文件。
- unresolved_questions：当前知乎页面与反馈后稿是否逐段一致；平台编辑历史与缺失 permalink；五篇思想书、白皮书和机制总览的全文作者审阅与事实核查；40 岁转行外部验证的地域、就业类型和参与者招募。
- 背景：v0.2.9 之后，项目形成需求归属与公众第一责任、第一原则 v1.0 语义冻结、七条公众命题、制度白皮书与五机制研究结构、司法解释草案、人生周期走查、缺席后果候选、公众反馈记录和首轮外部验证计划。公众“三步”稿已吸收资源承诺、成本转移和制度工程反馈，但旧知乎版本与当前修订稿必须分开。
- 决定：以 Markdown 白名单冻结并公开 `v0.3.0` 研究快照；保持所有草案和验证状态原样。反馈后三步稿以 GitHub `v0.3.0` 快照作为 `PUB-2026-003` 的冻结表征，不宣称知乎同步更新。
- 理由：版本发布应让当前研究状态可公开核对，同时不能把仓库可见性误写成内容定稿或制度有效性。单列新 PUB 记录可以保留旧稿、反馈和修订之间的版本关系。
- 后果：生成 `v0.3.0`；`main` 与 `v0.3.0` 快照分支指向同一发布提交；`Unreleased` 记录进入正式版本段；下一轮工作重新从空的 `Unreleased` 开始。
- 未采用方案：把全库文件机械改为同一版本；把所有 `draft` 升为 `stable`；把 GitHub 发布当作知乎重发、作者逐句批准、事实核查完成或现实制度验证；覆盖历史 PUB 快照；上传 `.DS_Store`、外部附件或本机杂项。

## D-033 · 固定 40 岁转行首次外部验证的上海养老护理员范围

- 状态：Accepted
- 日期：2026-08-26
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-57C2A8`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：把首次外部验证的收窄基线固定为中国大陆上海市、40 岁普通企业职工主动离职后转向养老护理员。
- source_ids：`SRC-57C2A8D4`
- supersedes：只解决 `D-031` 中地域与目标职业尚未确定的未决部分；不改变三方案比较、禁止现实干预、参与保护、停止线和验证状态。
- affected_documents：`08_Research_Workbench/07_Validation_Records/External_Validation_Plans/`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`PROJECT_INDEX.md`、`CHANGELOG.md`、来源与确认记录。
- unresolved_questions：性别、户籍、学历、住房、流动资金；直接用工、劳务派遣、居家社区或长期护理保险服务分支；零经验入口；培训、评价、工资、班次、带教、职业伤害和老年服务对象参与；邀请、补偿、存储、删除、投诉和独立复核。
- 背景：`D-031` 已确定 40 岁转行为首次外部验证，但当时没有地域和目标职业，无法核对社保、培训、资格、用工和第三方安全。项目发起者本轮明确指定上海市普通企业职工主动辞职转向养老护理员。
- 决定：建立 `BASE-40-SH-CARE-2026-01`，把地域固定为中国大陆上海市，把对象固定为 40 岁普通企业职工本人主动离职后转向养老护理员；继续在同一收窄情境中比较现制、现制内局部修补与 Aletheia 候选。
- 理由：只有固定地域、原就业身份、离职方式和目标职业，现制基线与三方案比较才有共同对象；其余个人条件、用工分支、复核视角和安全程序仍须在研究材料中明示，不由本决定代为确认。
- 后果：方案进入 `material-preparation`，不再以“地域和职业未选”为阻断；但仍为 `not-ready / validation_effect: none / planned-not-sent`。后续官方资料、复核分组和安全边界属于待审研究设计，不因本决定获得 Accepted 地位。
- 未采用方案：把“养老护理员”视为统一低风险岗位；把培训、证书、录用和任务授权合并；把主动辞职者默认写成领取失业保险金；把后置补贴写成即时生活费；让真实老人接受未经审查的新手服务；把场景选定写成验证已经开始。

## D-034 · 确认上海养老护理员首轮比较的六项研究假设

- 状态：Accepted
- 日期：2026-08-26
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-3F8A6D`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：确认原单位与最后社保缴费地在上海、普通主动辞职、零养老护理经验与相关资格、备案养老机构直接用工主线、五项个人条件作为敏感性分支，以及主线不预设就业困难人员认定。
- source_ids：`SRC-3F8A6D12`
- supersedes：补充 `D-033` 的比较设置，不改变上海养老护理员场景范围，不改变三方案、停止线、参与保护或验证状态。
- affected_documents：`08_Research_Workbench/07_Validation_Records/External_Validation_Plans/`、`DOCUMENT_STATUS.md`、`ROADMAP.md`、`CHANGELOG.md`、来源与确认记录。
- unresolved_questions：六项设置在现实上海经办、培训、评价、用工和服务对象权益材料中是否准确；各敏感性分支的实际差异；邀请、补偿、存储、删除、投诉和独立复核。
- 背景：`D-033` 已固定地域、年龄、原就业身份、离职方式和目标职业，但外部复核仍需同一人物和时间线。项目发起者随后确认采用建议的六项研究设置。
- 决定：以六项设置作为 `BASE-40-SH-CARE-2026-01` 首轮比较主线；性别、户籍、学历、住房、流动资金分别进入敏感性分支，就业困难人员认定另作联合资格结果，不把任何有利条件自动补入主线。
- 理由：区分主线研究假设与敏感性变量，可以让 A、B、C 三方案面对同一处境，同时避免把政策资格、储蓄或住房优势预先送给某一方案。
- 后果：直接用工主线和敏感性变量的组织方式不再属于作者待决定项；下一步转为经办与实践预核、参与保护和资料治理。验证仍未开始。
- 未采用方案：把六项写成现实个人事实；把未获认定的就业困难支持填入现金流；把直接用工结论外推到全部养老护理岗位；据此发送邀请或升级验证状态。

## D-035 · 确认哲学理论五项桥梁进入框架层

- 状态：Accepted
- 日期：2026-09-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-6E4A91B2`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：确认四类命题层级、弱者选择权、创新公共回流、劳动主体承认与冲突不可逆伤害边界进入项目理论解释层；不修改第一原则 v1.0，不确认机制参数或现实验证。
- source_ids：`SRC-5F8A2C19`
- supersedes：不取代 `D-030` 的第一原则冻结，不改变 `D-029` 的七条公众核心命题；只补充理论基础与制度推论之间的桥梁文档。
- affected_documents：`03_Aletheia_Framework/哲学理论基础与制度推论.md`、`03_Aletheia_Framework/README.md`、`07_Writing/Project_Overview/项目总纲.md`、`DOCUMENT_STATUS.md`、`CHANGELOG.md`、来源与确认记录。
- unresolved_questions：经验假设的外部证据；创新公共化的正当程序、回馈期限和开放方式；效率提升分配的参与者、比例和争议处理；弱者选择错误的合理后果边界；不可逆伤害在不同制度场景中的判定标准。
- 背景：项目已冻结第一原则 v1.0，并完成需求归属、公共责任、机制层与 40 岁转行现制材料整理；后续讨论显示仍需要一份更清楚的理论桥梁，把价值判断、事实判断、经验假设和制度推论分开，并补足劳动承认、创新回流、弱者选择权和冲突边界。
- 决定：新增《哲学理论基础与制度推论》，作为框架层草案保存五项桥梁。该文档只解释当前理论方向和下游推论，不把经验假设、激励分配或公共化路径写成已验证机制。
- 理由：将这些内容单独成文，可以避免把价值判断直接写成事实，也避免让机制草案反向改写第一原则；同时补足项目中“承认劳动主体”“创新怎样从私人或协作需求回流公共需求”“弱者怎样在不完整主见中保留选择权”等缺口。
- 后果：项目理论层增加一个新的 `draft` 入口；项目总纲和框架导航可引用该桥梁，但第一原则 v1.0 保持冻结。后续机制研究须继续说明成本、受影响者、竞争方案、停止线和可逆性。
- 未采用方案：直接改写《第一原则.md》；把四层或五层需求的具体资源分配写成定案；把“自愿合作更稳定”当作已证明事实；把劳动效率回馈写成固定比例或法律公式；把创新公共化理解为无偿没收创造者成果。

## D-036 · 发布 v0.4.0 公共研究快照

- 状态：Accepted
- 日期：2026-09-15
- decision_owner：Project Aletheia project initiator
- confirmed_by：Project Aletheia project initiator
- confirmation_source：[`PCR-4E0A1F`](08_Research_Workbench/05_Provenance_and_Decision_Records/PROJECT_DECISION_CONFIRMATIONS.md)
- confirmation_scope：确认整理 `v0.4.0` 发布包并更新到公开 GitHub 仓库；版本名称为“Aletheia 哲学理论 v0.4.0：人的主体性、公共责任与制度边界”。
- source_ids：`SRC-4E0A1F92`
- supersedes：不取代任何理论或机制决定；只结束本轮 `Unreleased` 发布准备，并把 `D-035` 及其导航、状态和来源记录纳入公开快照。
- affected_documents：`VERSION.md`、`README.md`、`CHANGELOG.md`、`RELEASE_CHECKSUMS.md`、`DOCUMENT_STATUS.md`、`DECISION_LOG.md`、`08_Research_Workbench/05_Provenance_and_Decision_Records/` 及所有发布包 Markdown。
- unresolved_questions：哲学理论桥梁的外部证据与反例测试；创新公共化和效率回馈机制；40 岁转行材料的企业、经办、实践者和受影响者复核；所有草案的作者逐段审阅与事实核查。
- 背景：`D-035` 已补入理论桥梁，使项目在人的主体性、公共责任与制度边界之间有了独立框架入口。项目发起者要求将当前状态整理为 `v0.4.0` 并公开同步到 GitHub。
- 决定：以 Markdown 白名单生成 `v0.4.0` 发布包；发布树排除 `.DS_Store`、外部附件全文、ZIP、AppleDouble、脚本、可执行文件和本机杂项；将 `main` 与 `v0.4.0` 快照分支更新为同一提交。
- 理由：版本发布使理论补充、来源链和边界说明可公开核对，同时不把公开可见性误写成定稿、验证或授权。
- 后果：生成 `v0.4.0` 发布包并更新公开仓库；`Unreleased` 记录进入正式版本段；下一轮工作重新从空的 `Unreleased` 开始。
- 未采用方案：把第一原则 v1.0 解冻；把理论桥梁升级为已验证事实；把养老护理材料写成外部验证完成；上传 `.DS_Store`、外部附件、ZIP 或本机杂项。

## 新增决定模板

```text
## D-XXX · 标题

- 状态：Proposed / Accepted / Superseded / Rejected
- 日期：YYYY-MM-DD
- decision_owner：
- confirmed_by：
- confirmation_source：
- confirmation_scope：
- source_ids：
- supersedes：
- affected_documents：
- unresolved_questions：
- 背景：
- 决定：
- 理由：
- 后果：
- 未采用方案：
- 替代关系：
```
