---
title: SSRN working paper drafts
layer: publication
status: draft
version: 0.1
updated: 2026-09-17
---

# SSRN working paper drafts

This directory stores English working paper drafts prepared for possible SSRN submission. These drafts are public-facing research texts, not new definition sources for Project Aletheia.

Current drafts:

- [`Misallocated_Care_Needs_Power_and_Responsibility_in_Public_Elderly_Care.md`](Misallocated_Care_Needs_Power_and_Responsibility_in_Public_Elderly_Care.md)

